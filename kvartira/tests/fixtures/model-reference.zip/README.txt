3D reference blockout v01
Units: mm
OBJ can be opened in Blender, SketchUp (via import), FreeCAD and other 3D software.
Geometry follows the previously prepared reference coordinate model.
Do not use this version for construction documentation until wall thicknesses, openings and the hall contour are verified.
